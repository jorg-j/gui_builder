import os, json, shutil, time, pyautogui

def writer(stringz):
    with open('autog.txt','a')as f:
        f.write(stringz)
        f.write("\n")


def clickpos():
    time.sleep(2)
    global mouseposx
    global mouseposy
    
    mouseposx, mouseposy = pyautogui.position()
    st = "pyautogui.click(%s,%s)" %(mouseposx, mouseposy)
    writer(st)
    print('saved')

def dragpos():
    time.sleep(2)
    global mouseposx
    global mouseposy
    mouseposx, mouseposy = pyautogui.position()
    st = "pyautogui.moveTo(%s,%s)" %(mouseposx, mouseposy)
    writer(st)
    print('mark1')
    time.sleep(2)
    mouseposx, mouseposy = pyautogui.position()
    st = "pyautogui.dragTo(%s,%s)" %(mouseposx, mouseposy)
    writer(st)
    print('saved')

def typer():
    x = pyautogui.prompt()
    st = "pyautogui.typewrite('%s')" %(x)
    writer(st)
    print('saved')
    
def tab():
    st = "pyautogui.hotkey('tab')"
    writer(st)
    print('saved')
    
def ent():
    st = "pyautogui.hotkey('enter')"
    writer(st)
    print('saved')   

def timedelay():
    x = pyautogui.prompt()
    st = "time.sleep(%s)" %(x)
    writer(st)
    print('saved')

def timedelayd():
    st = "time.sleep(1)"
    writer(st)
    print('saved')

def cfunt(com):
    st = "pyautogui.hotkey('ctrl','%s')" %(com)
    writer(st)
    print('saved')   

def direction(direct):
    st = "pyautogui.hotkey('%s')" %(direct)
    writer(st)
    print('saved')
