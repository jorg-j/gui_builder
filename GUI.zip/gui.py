import time, pyautogui

pyautogui.click(596,41)
pyautogui.typewrite('test 123')
pyautogui.hotkey('enter')
pyautogui.hotkey('right')
pyautogui.typewrite('test 234')
pyautogui.hotkey('enter')
pyautogui.hotkey('up')
pyautogui.hotkey('ctrl','c')
pyautogui.hotkey('down')
pyautogui.hotkey('ctrl','v')
