from tkinter import *
##from tkinter.ttk import *
import os, json, requests, shutil, time, datetime, pyautogui
import commander as c

mouseposx = 0
mouseposy = 0
typeset = ''
bgcol = "Black"
fgcol = "White"
fonty = "FreeMono"
###
window = Tk()
window.title("Program")
window.geometry('350x200')
statuss = ""
##Label
lbl_title = Label(window, text="", font=(fonty, 12))
lbl_title.grid(column=2, row=0)
##
lbl_status = Label(window, text=statuss, font=(fonty, 12))
lbl_status.grid(column=2, row=5)





## Button
btn_time = Button(window, text="Time Sleep", bg=bgcol, fg=fgcol, command=c.timedelay)
btn_time.grid(column=2, row=1)

btn_tsd = Button(window, text="Time Sleep Default", bg=bgcol, fg=fgcol, command=c.timedelayd)
btn_tsd.grid(column=1, row=1)

btn_type = Button(window, text="Type", bg=bgcol, fg=fgcol, command=c.typer)
btn_type.grid(column=4, row=1)

btn_clicker = Button(window, text="Click", bg=bgcol, fg=fgcol, command=c.clickpos)
btn_clicker.grid(column=1, row=4)

btn_drag = Button(window, text="Drag", bg=bgcol, fg=fgcol, command=c.dragpos)
btn_drag.grid(column=2, row=4)





btn_tab = Button(window, text="Tab", bg=bgcol, fg=fgcol, command=c.tab)
btn_tab.grid(column=1, row=6)
btn_tabe = Button(window, text="Enter", bg=bgcol, fg=fgcol, command=c.ent)
btn_tabe.grid(column=2, row=6)

btn_tabc = Button(window, text="Copy", bg=bgcol, fg=fgcol, command= lambda: c.cfunt('c'))
btn_tabc.grid(column=3, row=3)
btn_tabv = Button(window, text="Paste", bg=bgcol, fg=fgcol, command= lambda: c.cfunt('v'))
btn_tabv.grid(column=4, row=3)
btn_taba = Button(window, text="Sel All", bg=bgcol, fg=fgcol, command= lambda: c.cfunt('a'))
btn_taba.grid(column=5, row=3)


btn_up = Button(window, text="Up", bg=bgcol, fg=fgcol, command= lambda: c.direction('up'))
btn_up.grid(column=5, row=5)
btn_left = Button(window, text="left", bg=bgcol, fg=fgcol, command= lambda: c.direction('left'))
btn_left.grid(column=4, row=6)
btn_right = Button(window, text="right", bg=bgcol, fg=fgcol, command= lambda: c.direction('right'))
btn_right.grid(column=6, row=6)
btn_down = Button(window, text="down", bg=bgcol, fg=fgcol, command= lambda: c.direction('down'))
btn_down.grid(column=5, row=7)



window.mainloop()


